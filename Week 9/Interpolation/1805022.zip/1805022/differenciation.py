from sympy import *
from mass import findValue as mFind
from mass import findTable as mTable

from velocity import findValue as vFind
from velocity import findTable as vTable

x = Symbol('x')
mx,my,mn = mTable()
vx,vy,vn = vTable()
f = mFind(x,mx,my,mn)*vFind(x,vx,vy,vn)
f_prime = f.diff(x)
print(f)
print(f_prime)
f_prime = lambdify(x, f_prime)
print(f_prime(25))